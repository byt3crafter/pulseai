/* @ds-bundle: {"format":3,"namespace":"MusterDesignSystem_7b1541","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/data/Avatar.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"StatCard","sourcePath":"components/data/StatCard.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"StatusPill","sourcePath":"components/feedback/StatusPill.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"SidebarNav","sourcePath":"components/navigation/SidebarNav.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Button.jsx":"b06879784f6c","components/core/IconButton.jsx":"68083d58ea37","components/data/Avatar.jsx":"0070b13dfcc3","components/data/Card.jsx":"c38af463a281","components/data/StatCard.jsx":"6d4c7aca633f","components/feedback/Badge.jsx":"55787c944af2","components/feedback/StatusPill.jsx":"12b3651a8d6a","components/feedback/Toast.jsx":"6dc0750e4ca5","components/forms/Checkbox.jsx":"7b4cb77abde7","components/forms/Input.jsx":"5fa36e06f2b8","components/forms/Select.jsx":"cedbb5bcce10","components/forms/Switch.jsx":"e804d575ab1d","components/navigation/SidebarNav.jsx":"e65e687d429e","components/navigation/Tabs.jsx":"fd0b4211621b","ui_kits/admin/AttendanceView.jsx":"cb4f977b2408","ui_kits/admin/DashboardView.jsx":"59f5ee6a1f15","ui_kits/admin/data.js":"fb5fc74766cc","ui_kits/clock/ClockScreen.jsx":"2cd3045e5e20","ui_kits/site/SiteScreen.jsx":"9bc42d62cd6f"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MusterDesignSystem_7b1541 = window.MusterDesignSystem_7b1541 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Muster Button — the primary action primitive.
 * Variants map to intent; sizes map to surface (sm/md for admin, lg/xl for touch).
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft = null,
  iconRight = null,
  fullWidth = false,
  loading = false,
  disabled = false,
  type = "button",
  onClick,
  style = {},
  ...rest
}) {
  const heights = {
    sm: "var(--control-h-sm)",
    md: "var(--control-h-md)",
    lg: "var(--control-h-lg)",
    xl: "var(--control-h-xl)"
  };
  const pads = {
    sm: "0 12px",
    md: "0 16px",
    lg: "0 22px",
    xl: "0 28px"
  };
  const fontSizes = {
    sm: "13px",
    md: "14px",
    lg: "15px",
    xl: "17px"
  };
  const variants = {
    primary: {
      background: "var(--brand-primary)",
      color: "var(--brand-primary-fg)",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-xs)"
    },
    accent: {
      background: "var(--brand-accent)",
      color: "var(--brand-accent-fg)",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-xs)"
    },
    secondary: {
      background: "var(--surface-card)",
      color: "var(--text-strong)",
      border: "1px solid var(--border-default)",
      boxShadow: "var(--shadow-xs)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-body)",
      border: "1px solid transparent"
    },
    danger: {
      background: "var(--danger)",
      color: "#fff",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-xs)"
    }
  };
  const isDisabled = disabled || loading;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "8px",
    height: heights[size],
    padding: pads[size],
    width: fullWidth ? "100%" : "auto",
    fontFamily: "var(--font-sans)",
    fontSize: fontSizes[size],
    fontWeight: "var(--weight-semibold)",
    letterSpacing: "-0.005em",
    lineHeight: 1,
    borderRadius: "var(--radius-md)",
    cursor: isDisabled ? "not-allowed" : "pointer",
    opacity: isDisabled ? 0.55 : 1,
    whiteSpace: "nowrap",
    transition: "var(--transition-colors), transform var(--dur-fast) var(--ease-snap), box-shadow var(--dur-fast) var(--ease-out)",
    ...variants[variant],
    ...style
  };
  const onDown = e => {
    if (!isDisabled) e.currentTarget.style.transform = "scale(0.975)";
  };
  const onUp = e => {
    e.currentTarget.style.transform = "scale(1)";
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: isDisabled,
    onClick: onClick,
    onMouseDown: onDown,
    onMouseUp: onUp,
    onMouseLeave: onUp,
    style: base
  }, rest), loading && /*#__PURE__*/React.createElement(Spinner, null), !loading && iconLeft, children, !loading && iconRight);
}
function Spinner() {
  return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      width: "15px",
      height: "15px",
      border: "2px solid currentColor",
      borderTopColor: "transparent",
      borderRadius: "999px",
      display: "inline-block",
      animation: "muster-spin 0.6s linear infinite",
      opacity: 0.9
    }
  });
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — a square, icon-only control. Always pass `label` for a11y.
 * Pass a Lucide <i data-lucide="..."> (or any node) as children.
 */
function IconButton({
  children,
  label,
  variant = "ghost",
  size = "md",
  active = false,
  disabled = false,
  onClick,
  style = {},
  ...rest
}) {
  const dims = {
    sm: 32,
    md: 40,
    lg: 48
  };
  const d = dims[size];
  const variants = {
    ghost: {
      background: active ? "var(--surface-sunken)" : "transparent",
      color: active ? "var(--brand-primary)" : "var(--text-muted)",
      border: "1px solid transparent"
    },
    outlined: {
      background: "var(--surface-card)",
      color: "var(--text-body)",
      border: "1px solid var(--border-default)",
      boxShadow: "var(--shadow-xs)"
    },
    solid: {
      background: "var(--brand-primary)",
      color: "var(--brand-primary-fg)",
      border: "1px solid transparent",
      boxShadow: "var(--shadow-xs)"
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: d,
      height: d,
      flex: "0 0 auto",
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transition: "var(--transition-colors), transform var(--dur-fast) var(--ease-snap)",
      ...variants[variant],
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = "scale(0.92)";
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = "scale(1)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = "scale(1)";
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data/Avatar.jsx
try { (() => {
/**
 * Avatar — employee portrait or initials. Optional status ring/dot keyed to
 * the attendance palette (e.g. green when on the clock).
 */
function Avatar({
  name = "",
  src,
  size = 40,
  status,
  square = false,
  style = {}
}) {
  const initials = name.split(" ").filter(Boolean).slice(0, 2).map(p => p[0]?.toUpperCase()).join("");
  const statusColors = {
    present: "var(--status-present-dot)",
    live: "var(--status-live-dot)",
    late: "var(--status-late-dot)",
    absent: "var(--status-absent-dot)",
    leave: "var(--status-leave-dot)",
    off: "var(--status-off-dot)"
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex",
      flex: "0 0 auto",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      borderRadius: square ? "var(--radius-md)" : "var(--radius-pill)",
      overflow: "hidden",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--surface-brand-soft)",
      color: "var(--teal-700)",
      fontFamily: "var(--font-display)",
      fontWeight: "var(--weight-semibold)",
      fontSize: Math.max(11, size * 0.36),
      letterSpacing: "0.01em",
      border: "1px solid var(--border-subtle)",
      userSelect: "none"
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials || "·"), status && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: -1,
      bottom: -1,
      width: Math.max(9, size * 0.28),
      height: Math.max(9, size * 0.28),
      borderRadius: "var(--radius-pill)",
      background: statusColors[status] || "var(--stone-400)",
      border: "2px solid var(--surface-card)",
      animation: status === "live" ? "muster-live-pulse 2s var(--ease-out) infinite" : "none"
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — the base surface container. White, 1px hairline border, soft shadow,
 * 10px radius. Optional header (title + eyebrow + action) and padding control.
 */
function Card({
  children,
  title,
  eyebrow,
  action,
  padding = "md",
  interactive = false,
  style = {},
  bodyStyle = {},
  ...rest
}) {
  const pads = {
    none: "0",
    sm: "14px",
    md: "20px",
    lg: "24px"
  };
  const hasHeader = title || eyebrow || action;
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-sm)",
      overflow: "hidden",
      transition: interactive ? "box-shadow var(--dur-base) var(--ease-out), border-color var(--dur-base) var(--ease-out)" : "none",
      cursor: interactive ? "pointer" : "default",
      ...style
    },
    onMouseEnter: interactive ? e => {
      e.currentTarget.style.boxShadow = "var(--shadow-md)";
      e.currentTarget.style.borderColor = "var(--border-default)";
    } : undefined,
    onMouseLeave: interactive ? e => {
      e.currentTarget.style.boxShadow = "var(--shadow-sm)";
      e.currentTarget.style.borderColor = "var(--border-subtle)";
    } : undefined
  }, rest), hasHeader && /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 12,
      padding: padding === "none" ? "16px 16px 0" : `${pads[padding]} ${pads[padding]} 0`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 4
    }
  }, eyebrow), title && /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 16,
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-strong)",
      letterSpacing: "-0.01em",
      lineHeight: 1.3
    }
  }, title)), action && /*#__PURE__*/React.createElement("div", {
    style: {
      flex: "0 0 auto"
    }
  }, action)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: pads[padding],
      paddingTop: hasHeader && padding !== "none" ? 14 : pads[padding],
      ...bodyStyle
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/data/StatCard.jsx
try { (() => {
/**
 * StatCard — a headline metric tile. Big tabular number + label, optional
 * delta and an accent stripe keyed to status/intent.
 */
function StatCard({
  label,
  value,
  unit,
  delta,
  deltaDir = "up",
  icon,
  accent = "brand",
  style = {}
}) {
  const accents = {
    brand: "var(--brand-primary)",
    accent: "var(--brand-accent)",
    success: "var(--success)",
    danger: "var(--danger)",
    neutral: "var(--stone-400)"
  };
  const deltaColor = deltaDir === "down" ? "var(--danger)" : "var(--success)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-sm)",
      padding: "16px 18px",
      overflow: "hidden",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      top: 0,
      bottom: 0,
      width: 3,
      background: accents[accent]
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: accents[accent],
      opacity: 0.9,
      display: "inline-flex"
    }
  }, icon)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 32,
      fontWeight: "var(--weight-bold)",
      letterSpacing: "-0.02em",
      color: "var(--text-strong)",
      lineHeight: 1,
      fontVariantNumeric: "tabular-nums lining-nums"
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: "var(--weight-medium)",
      color: "var(--text-muted)"
    }
  }, unit)), delta != null && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      marginTop: 8,
      fontSize: 12,
      fontWeight: "var(--weight-semibold)",
      color: deltaColor
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": deltaDir === "down" ? "trending-down" : "trending-up",
    style: {
      width: 14,
      height: 14
    }
  }), delta));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
/** Badge — small count/label chip for tags, counts and metadata. */
function Badge({
  children,
  tone = "neutral",
  variant = "soft",
  size = "md",
  style = {}
}) {
  const tones = {
    neutral: {
      soft: ["var(--surface-sunken)", "var(--text-body)"],
      solid: ["var(--stone-700)", "#fff"],
      outline: ["transparent", "var(--text-body)"]
    },
    brand: {
      soft: ["var(--surface-brand-soft)", "var(--teal-700)"],
      solid: ["var(--brand-primary)", "var(--brand-primary-fg)"],
      outline: ["transparent", "var(--brand-primary)"]
    },
    accent: {
      soft: ["var(--surface-accent-soft)", "var(--amber-700)"],
      solid: ["var(--brand-accent)", "var(--brand-accent-fg)"],
      outline: ["transparent", "var(--amber-700)"]
    },
    success: {
      soft: ["var(--success-soft)", "var(--success)"],
      solid: ["var(--success)", "#fff"],
      outline: ["transparent", "var(--success)"]
    },
    warning: {
      soft: ["var(--warning-soft)", "var(--amber-800)"],
      solid: ["var(--warning)", "#fff"],
      outline: ["transparent", "var(--amber-800)"]
    },
    danger: {
      soft: ["var(--danger-soft)", "var(--danger)"],
      solid: ["var(--danger)", "#fff"],
      outline: ["transparent", "var(--danger)"]
    },
    info: {
      soft: ["var(--info-soft)", "var(--info)"],
      solid: ["var(--info)", "#fff"],
      outline: ["transparent", "var(--info)"]
    }
  };
  const [bg, fg] = tones[tone][variant];
  const sm = size === "sm";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 4,
      height: sm ? 18 : 22,
      padding: sm ? "0 6px" : "0 8px",
      background: bg,
      color: fg,
      border: variant === "outline" ? "1px solid currentColor" : "1px solid transparent",
      borderRadius: "var(--radius-sm)",
      fontFamily: "var(--font-sans)",
      fontSize: sm ? "10.5px" : "11.5px",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "0.01em",
      lineHeight: 1,
      whiteSpace: "nowrap",
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusPill.jsx
try { (() => {
/**
 * StatusPill — the domain-signature component. Renders an attendance status
 * with a soft-tint background, a saturated dot, and dark-tint text. The
 * `live` ("on the clock") status gets the brand pulse animation.
 */

const STATUS = {
  present: {
    label: "Present",
    fg: "--status-present-fg",
    bg: "--status-present-bg",
    dot: "--status-present-dot"
  },
  live: {
    label: "On the clock",
    fg: "--status-live-fg",
    bg: "--status-live-bg",
    dot: "--status-live-dot"
  },
  late: {
    label: "Late",
    fg: "--status-late-fg",
    bg: "--status-late-bg",
    dot: "--status-late-dot"
  },
  overtime: {
    label: "Overtime",
    fg: "--status-overtime-fg",
    bg: "--status-overtime-bg",
    dot: "--status-overtime-dot"
  },
  absent: {
    label: "Absent",
    fg: "--status-absent-fg",
    bg: "--status-absent-bg",
    dot: "--status-absent-dot"
  },
  leave: {
    label: "On leave",
    fg: "--status-leave-fg",
    bg: "--status-leave-bg",
    dot: "--status-leave-dot"
  },
  holiday: {
    label: "Public holiday",
    fg: "--status-holiday-fg",
    bg: "--status-holiday-bg",
    dot: "--status-holiday-dot"
  },
  off: {
    label: "Day off",
    fg: "--status-off-fg",
    bg: "--status-off-bg",
    dot: "--status-off-dot"
  }
};
function StatusPill({
  status = "present",
  label,
  size = "md",
  dotOnly = false,
  style = {}
}) {
  const s = STATUS[status] || STATUS.present;
  const text = label ?? s.label;
  const isLive = status === "live";
  const dot = /*#__PURE__*/React.createElement("span", {
    style: {
      width: size === "sm" ? 7 : 8,
      height: size === "sm" ? 7 : 8,
      borderRadius: "var(--radius-pill)",
      background: `var(${s.dot})`,
      flex: "0 0 auto",
      animation: isLive ? "muster-live-pulse 2s var(--ease-out) infinite" : "none"
    }
  });
  if (dotOnly) return dot;
  const sm = size === "sm";
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: sm ? 5 : 6,
      height: sm ? 20 : 24,
      padding: sm ? "0 8px" : "0 10px",
      borderRadius: "var(--radius-pill)",
      background: `var(${s.bg})`,
      color: `var(${s.fg})`,
      fontFamily: "var(--font-sans)",
      fontSize: sm ? "11px" : "12px",
      fontWeight: "var(--weight-semibold)",
      letterSpacing: "0.01em",
      lineHeight: 1,
      whiteSpace: "nowrap",
      ...style
    }
  }, dot, text);
}
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
/** Toast — transient confirmation/alert. Static (non-dismissing) for kits/specimens. */
function Toast({
  title,
  message,
  tone = "success",
  onClose,
  style = {}
}) {
  const tones = {
    success: {
      icon: "check-circle-2",
      color: "var(--success)"
    },
    info: {
      icon: "info",
      color: "var(--info)"
    },
    warning: {
      icon: "alert-triangle",
      color: "var(--warning)"
    },
    danger: {
      icon: "alert-octagon",
      color: "var(--danger)"
    }
  };
  const t = tones[tone] || tones.success;
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 12,
      width: "min(380px, 92vw)",
      padding: "12px 14px",
      background: "var(--surface-raised)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-lg)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 28,
      height: 28,
      flex: "0 0 auto",
      borderRadius: "var(--radius-sm)",
      background: "color-mix(in oklch, " + t.color + " 14%, transparent)",
      color: t.color
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": t.icon,
    style: {
      width: 17,
      height: 17
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      paddingTop: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5,
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-strong)",
      lineHeight: 1.3
    }
  }, title), message && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-muted)",
      marginTop: title ? 2 : 0,
      lineHeight: 1.4
    }
  }, message)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      background: "transparent",
      border: "none",
      cursor: "pointer",
      color: "var(--text-faint)",
      padding: 2,
      marginTop: -1,
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 16,
      height: 16
    }
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
/** Checkbox — labelled box with brand fill when checked. Controlled or uncontrolled. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  description,
  disabled = false,
  onChange,
  style = {}
}) {
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const isControlled = checked != null;
  const on = isControlled ? checked : internal;
  const toggle = e => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on, e);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: description ? "flex-start" : "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: toggle,
    style: {
      width: 18,
      height: 18,
      flex: "0 0 auto",
      marginTop: description ? 1 : 0,
      borderRadius: "var(--radius-xs)",
      border: `1.5px solid ${on ? "var(--brand-primary)" : "var(--border-strong)"}`,
      background: on ? "var(--brand-primary)" : "var(--surface-card)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "var(--transition-colors)"
    }
  }, on && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check",
    style: {
      width: 13,
      height: 13,
      color: "var(--brand-primary-fg)",
      strokeWidth: 3
    }
  })), (label || description) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: "var(--text-strong)",
      fontWeight: "var(--weight-medium)",
      lineHeight: 1.35
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      color: "var(--text-muted)",
      lineHeight: 1.4
    }
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Input — labelled text field with optional icon, hint and error. */
function Input({
  label,
  value,
  defaultValue,
  placeholder,
  type = "text",
  icon,
  hint,
  error,
  size = "md",
  disabled = false,
  required = false,
  onChange,
  style = {},
  ...rest
}) {
  const heights = {
    sm: "var(--control-h-sm)",
    md: "var(--control-h-md)",
    lg: "var(--control-h-lg)"
  };
  const id = React.useId();
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      fontSize: 12.5,
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-strong)"
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--danger)",
      marginLeft: 2
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      height: heights[size],
      padding: "0 12px",
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      border: `1px solid ${error ? "var(--danger)" : focus ? "var(--brand-primary)" : "var(--border-default)"}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "var(--focus-ring)" : "none",
      transition: "border-color var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)",
      opacity: disabled ? 0.6 : 1
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-faint)",
      display: "inline-flex",
      flex: "0 0 auto"
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    id: id,
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: size === "sm" ? 13 : 14,
      color: "var(--text-strong)"
    }
  }, rest))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: error ? "var(--danger)" : "var(--text-muted)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Select — labelled native dropdown styled to match Input. */
function Select({
  label,
  value,
  defaultValue,
  options = [],
  hint,
  error,
  size = "md",
  disabled = false,
  onChange,
  style = {},
  ...rest
}) {
  const heights = {
    sm: "var(--control-h-sm)",
    md: "var(--control-h-md)",
    lg: "var(--control-h-lg)"
  };
  const id = React.useId();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      fontSize: 12.5,
      fontWeight: "var(--weight-semibold)",
      color: "var(--text-strong)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: id,
    value: value,
    defaultValue: defaultValue,
    disabled: disabled,
    onChange: onChange,
    style: {
      width: "100%",
      height: heights[size],
      padding: "0 36px 0 12px",
      appearance: "none",
      WebkitAppearance: "none",
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      border: `1px solid ${error ? "var(--danger)" : "var(--border-default)"}`,
      borderRadius: "var(--radius-md)",
      fontFamily: "var(--font-sans)",
      fontSize: size === "sm" ? 13 : 14,
      color: "var(--text-strong)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.6 : 1,
      outline: "none"
    }
  }, rest), options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: 12,
      top: "50%",
      transform: "translateY(-50%)",
      pointerEvents: "none",
      color: "var(--text-muted)",
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-down",
    style: {
      width: 16,
      height: 16
    }
  }))), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: error ? "var(--danger)" : "var(--text-muted)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
/** Switch — on/off toggle. Brand fill when on. Controlled or uncontrolled. */
function Switch({
  checked,
  defaultChecked,
  label,
  disabled = false,
  size = "md",
  onChange,
  style = {}
}) {
  const [internal, setInternal] = React.useState(!!defaultChecked);
  const isControlled = checked != null;
  const on = isControlled ? checked : internal;
  const dims = size === "sm" ? {
    w: 34,
    h: 20,
    k: 14
  } : {
    w: 42,
    h: 24,
    k: 18
  };
  const toggle = e => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on, e);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.55 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: toggle,
    role: "switch",
    "aria-checked": on,
    style: {
      position: "relative",
      width: dims.w,
      height: dims.h,
      flex: "0 0 auto",
      borderRadius: "var(--radius-pill)",
      background: on ? "var(--brand-primary)" : "var(--stone-300)",
      transition: "background-color var(--dur-base) var(--ease-out)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: (dims.h - dims.k) / 2,
      left: on ? dims.w - dims.k - (dims.h - dims.k) / 2 : (dims.h - dims.k) / 2,
      width: dims.k,
      height: dims.k,
      borderRadius: "var(--radius-pill)",
      background: "#fff",
      boxShadow: "var(--shadow-sm)",
      transition: "left var(--dur-base) var(--ease-snap)"
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: "var(--text-strong)",
      fontWeight: "var(--weight-medium)"
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SidebarNav.jsx
try { (() => {
/**
 * SidebarNav — the admin shell's left navigation. Renders the Muster mark,
 * grouped nav items (Lucide icons + label + optional count), and an active
 * state keyed to the brand. Pass items as a flat list or with `section` heads.
 */
function SidebarNav({
  items = [],
  active,
  onSelect,
  brandName = "Muster",
  footer,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      width: "var(--sidebar-w)",
      height: "100%",
      flex: "0 0 auto",
      background: "var(--surface-card)",
      borderRight: "1px solid var(--border-subtle)",
      display: "flex",
      flexDirection: "column",
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "16px 16px",
      height: "var(--topbar-h)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: 8,
      background: "var(--brand-primary)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 2.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 3,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      width: 4,
      height: 4,
      borderRadius: 9,
      background: "var(--brand-accent)"
    }
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      width: 11,
      height: 2.5,
      borderRadius: 2,
      background: "#fff"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 3,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      width: 4,
      height: 4,
      borderRadius: 9,
      background: "#fff"
    }
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      width: 8,
      height: 2.5,
      borderRadius: 2,
      background: "rgba(255,255,255,.7)"
    }
  })))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: "var(--weight-bold)",
      fontSize: 17,
      color: "var(--text-strong)",
      letterSpacing: "-0.01em"
    }
  }, brandName)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "10px 10px"
    }
  }, items.map((it, i) => {
    if (it.section) {
      return /*#__PURE__*/React.createElement("div", {
        key: "s" + i,
        style: {
          fontSize: 10.5,
          fontWeight: "var(--weight-semibold)",
          letterSpacing: "var(--tracking-caps)",
          textTransform: "uppercase",
          color: "var(--text-faint)",
          padding: "14px 10px 6px"
        }
      }, it.section);
    }
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      onClick: () => onSelect && onSelect(it.id),
      style: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "9px 10px",
        marginBottom: 2,
        background: on ? "var(--surface-brand-soft)" : "transparent",
        border: "none",
        borderRadius: "var(--radius-sm)",
        cursor: "pointer",
        color: on ? "var(--teal-700)" : "var(--text-body)",
        fontFamily: "var(--font-sans)",
        fontSize: 13.5,
        fontWeight: on ? "var(--weight-semibold)" : "var(--weight-medium)",
        textAlign: "left",
        transition: "var(--transition-colors)"
      },
      onMouseEnter: e => {
        if (!on) e.currentTarget.style.background = "var(--surface-sunken)";
      },
      onMouseLeave: e => {
        if (!on) e.currentTarget.style.background = "transparent";
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        color: on ? "var(--brand-primary)" : "var(--text-muted)",
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": it.icon,
      style: {
        width: 18,
        height: 18
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, it.label), it.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: "var(--weight-semibold)",
        color: on ? "var(--brand-primary)" : "var(--text-faint)",
        background: on ? "#fff" : "var(--surface-sunken)",
        borderRadius: "var(--radius-pill)",
        padding: "1px 7px",
        lineHeight: 1.5
      }
    }, it.count));
  })), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-subtle)",
      padding: 12
    }
  }, footer));
}
Object.assign(__ds_scope, { SidebarNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SidebarNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/** Tabs — underline tab bar. Controlled (value+onChange) or uncontrolled. */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  style = {}
}) {
  const first = tabs[0] && (typeof tabs[0] === "string" ? tabs[0] : tabs[0].value);
  const [internal, setInternal] = React.useState(defaultValue ?? first);
  const active = value ?? internal;
  const select = v => {
    if (value == null) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    role: "tablist",
    style: {
      display: "flex",
      gap: 4,
      borderBottom: "1px solid var(--border-subtle)",
      ...style
    }
  }, tabs.map(t => {
    const tab = typeof t === "string" ? {
      value: t,
      label: t
    } : t;
    const on = tab.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.value,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(tab.value),
      style: {
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "10px 12px 12px",
        background: "transparent",
        border: "none",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: 13.5,
        fontWeight: on ? "var(--weight-semibold)" : "var(--weight-medium)",
        color: on ? "var(--text-strong)" : "var(--text-muted)",
        transition: "var(--transition-colors)"
      }
    }, tab.icon, tab.label, tab.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: "var(--weight-semibold)",
        color: on ? "var(--brand-primary)" : "var(--text-faint)",
        background: on ? "var(--surface-brand-soft)" : "var(--surface-sunken)",
        borderRadius: "var(--radius-pill)",
        padding: "1px 6px",
        lineHeight: 1.4
      }
    }, tab.count), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: 0,
        right: 0,
        bottom: -1,
        height: 2,
        background: on ? "var(--brand-primary)" : "transparent",
        borderRadius: "2px 2px 0 0",
        transition: "background-color var(--dur-fast) var(--ease-out)"
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/AttendanceView.jsx
try { (() => {
/* Muster Admin — Daily attendance view */
(function () {
  const {
    Card,
    Avatar,
    StatusPill,
    Button,
    Input,
    Select,
    IconButton,
    Badge
  } = window.MusterDesignSystem_7b1541;
  function AttendanceView() {
    const D = window.MUSTER_DATA;
    const [q, setQ] = React.useState("");
    const Ico = (n, s) => /*#__PURE__*/React.createElement("i", {
      "data-lucide": n,
      style: {
        width: s || 16,
        height: s || 16
      }
    });
    const rows = D.rows.filter(r => r.name.toLowerCase().includes(q.toLowerCase()) || r.code.toLowerCase().includes(q.toLowerCase()));
    const head = ["Employee", "Site", "In", "Out", "Hours", "OT", "Status", ""];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-end",
        gap: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Date",
      defaultValue: "14 Jun 2026",
      icon: Ico("calendar"),
      size: "md",
      style: {
        width: 170
      }
    })), /*#__PURE__*/React.createElement(Select, {
      label: "Site",
      options: ["All sites", "Port Louis yard", "Phoenix plant", "Curepipe depot"],
      style: {
        width: 180
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 200
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Search",
      placeholder: "Name or code\u2026",
      icon: Ico("search"),
      value: q,
      onChange: e => setQ(e.target.value)
    })), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      iconLeft: Ico("download")
    }, "Export CSV"), /*#__PURE__*/React.createElement(Button, {
      variant: "primary",
      iconLeft: Ico("plus")
    }, "Add punch")), /*#__PURE__*/React.createElement(Card, {
      padding: "none"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "12px 18px",
        borderBottom: "1px solid var(--border-subtle)",
        background: "var(--surface-sunken)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12.5,
        color: "var(--text-muted)"
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--text-strong)"
      }
    }, rows.length), " employees \xB7 ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--text-strong)"
      }
    }, "164"), " present \xB7 ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--text-strong)"
      }
    }, "6"), " absent"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      variant: "outline"
    }, "Mon\u2013Sat"), /*#__PURE__*/React.createElement(Badge, {
      tone: "accent",
      variant: "soft"
    }, "Sat half-day 13:00"), /*#__PURE__*/React.createElement(Badge, {
      tone: "brand",
      variant: "soft"
    }, "OT min 30m"))), /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
      style: {
        background: "var(--surface-card)"
      }
    }, head.map((h, i) => /*#__PURE__*/React.createElement("th", {
      key: i,
      style: {
        textAlign: i >= 2 && i <= 5 ? "right" : "left",
        fontSize: 10.5,
        fontWeight: 600,
        letterSpacing: ".06em",
        textTransform: "uppercase",
        color: "var(--text-faint)",
        padding: "12px 14px",
        position: "sticky",
        top: 0
      }
    }, h)))), /*#__PURE__*/React.createElement("tbody", null, rows.map(r => /*#__PURE__*/React.createElement("tr", {
      key: r.code,
      style: {
        borderTop: "1px solid var(--border-subtle)"
      },
      onMouseEnter: e => e.currentTarget.style.background = "var(--surface-sunken)",
      onMouseLeave: e => e.currentTarget.style.background = "transparent"
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "10px 14px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: r.name,
      size: 32,
      status: r.status === "live" ? "live" : undefined
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        fontWeight: 500,
        color: "var(--text-strong)",
        whiteSpace: "nowrap"
      }
    }, r.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        fontFamily: "var(--font-mono)",
        color: "var(--text-faint)"
      }
    }, r.code)))), /*#__PURE__*/React.createElement("td", {
      style: {
        fontSize: 12.5,
        color: "var(--text-muted)",
        whiteSpace: "nowrap",
        padding: "0 14px"
      }
    }, r.site), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: "var(--text-body)",
        padding: "0 14px"
      }
    }, r.in), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: "var(--text-body)",
        padding: "0 14px"
      }
    }, r.out), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        fontWeight: 600,
        color: "var(--text-strong)",
        padding: "0 14px"
      }
    }, r.hours === "—" ? "—" : r.hours), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: r.ot !== "—" && r.ot !== "0.0" ? "var(--status-overtime-dot)" : "var(--text-faint)",
        padding: "0 14px"
      }
    }, r.ot), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "0 14px"
      }
    }, /*#__PURE__*/React.createElement(StatusPill, {
      status: r.status,
      size: "sm"
    })), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "0 10px",
        textAlign: "right"
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      label: "Edit",
      size: "sm",
      variant: "ghost"
    }, Ico("pencil", 15))))))))));
  }
  window.AttendanceView = AttendanceView;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/AttendanceView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/DashboardView.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Muster Admin — Dashboard view */
(function () {
  const {
    StatCard,
    Card,
    Avatar,
    StatusPill,
    Button,
    Badge
  } = window.MusterDesignSystem_7b1541;
  function DashboardView() {
    const D = window.MUSTER_DATA;
    const Ico = (n, s) => /*#__PURE__*/React.createElement("i", {
      "data-lucide": n,
      style: {
        width: s || 16,
        height: s || 16
      }
    });
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: 14
      }
    }, D.kpis.map(k => /*#__PURE__*/React.createElement(StatCard, _extends({
      key: k.label
    }, k, {
      icon: Ico(k.icon, 18)
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1.4fr 1fr",
        gap: 20,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement(Card, {
      eyebrow: "Today \xB7 14 Jun",
      title: "Recent activity",
      padding: "none",
      action: /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "ghost",
        iconRight: Ico("arrow-right")
      }, "View all")
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 20px 8px"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ["Employee", "Site", "In", "Out", "Hours", "Status"].map((h, i) => /*#__PURE__*/React.createElement("th", {
      key: h,
      style: {
        textAlign: i > 1 && i < 5 ? "right" : "left",
        fontSize: 10.5,
        fontWeight: 600,
        letterSpacing: ".06em",
        textTransform: "uppercase",
        color: "var(--text-faint)",
        padding: "10px 10px 10px 0"
      }
    }, h)))), /*#__PURE__*/React.createElement("tbody", null, D.rows.slice(0, 6).map(r => /*#__PURE__*/React.createElement("tr", {
      key: r.code,
      style: {
        borderTop: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: "9px 10px 9px 0"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 9
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: r.name,
      size: 28,
      status: r.status === "live" ? "live" : undefined
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 500,
        color: "var(--text-strong)",
        whiteSpace: "nowrap"
      }
    }, r.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        fontFamily: "var(--font-mono)",
        color: "var(--text-faint)"
      }
    }, r.code)))), /*#__PURE__*/React.createElement("td", {
      style: {
        fontSize: 12.5,
        color: "var(--text-muted)",
        whiteSpace: "nowrap"
      }
    }, r.site), /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: "var(--text-body)"
      }
    }, r.in), /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: "var(--text-body)"
      }
    }, r.out), /*#__PURE__*/React.createElement("td", {
      className: "num",
      style: {
        textAlign: "right",
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: "var(--text-strong)",
        fontWeight: 500
      }
    }, r.hours === "—" ? "—" : r.hours + " h"), /*#__PURE__*/React.createElement("td", {
      style: {
        textAlign: "left",
        paddingLeft: 14
      }
    }, /*#__PURE__*/React.createElement(StatusPill, {
      status: r.status,
      size: "sm"
    })))))))), /*#__PURE__*/React.createElement(Card, {
      eyebrow: "On site now",
      title: "142 clocked in",
      action: /*#__PURE__*/React.createElement(Badge, {
        tone: "brand",
        variant: "soft"
      }, "Live")
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 12
      }
    }, D.live.map(p => /*#__PURE__*/React.createElement("div", {
      key: p.code,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: p.name,
      size: 34,
      status: "live"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 500,
        color: "var(--text-strong)"
      }
    }, p.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "var(--text-muted)"
      }
    }, p.site)), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "right"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: 13,
        color: "var(--text-strong)"
      }
    }, p.since), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10.5,
        color: "var(--text-faint)",
        letterSpacing: ".04em",
        textTransform: "uppercase"
      }
    }, "since")))), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "sm",
      fullWidth: true,
      iconLeft: Ico("map-pin")
    }, "Open site map")))));
  }
  window.DashboardView = DashboardView;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/DashboardView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/admin/data.js
try { (() => {
/* Shared mock data for the Muster Admin UI kit. Mauritius-flavoured names. */
window.MUSTER_DATA = {
  brand: {
    name: "Muster"
  },
  kpis: [{
    label: "On site now",
    value: 142,
    unit: "",
    accent: "brand",
    icon: "users",
    delta: "+8 since 6am",
    deltaDir: "up"
  }, {
    label: "Present today",
    value: "164",
    unit: "/ 178",
    accent: "success",
    icon: "calendar-check",
    delta: "92% turnout",
    deltaDir: "up"
  }, {
    label: "Hours this week",
    value: "3,204",
    unit: "h",
    accent: "accent",
    icon: "clock",
    delta: "+212 vs last",
    deltaDir: "up"
  }, {
    label: "Absent today",
    value: 6,
    unit: "",
    accent: "danger",
    icon: "user-x",
    delta: "-2 vs avg",
    deltaDir: "down"
  }],
  live: [{
    name: "Anjali Ramdin",
    code: "EMP-0421",
    site: "Port Louis yard",
    since: "07:58",
    status: "live"
  }, {
    name: "Priya Nuckchady",
    code: "EMP-0096",
    site: "Phoenix plant",
    since: "06:55",
    status: "live"
  }, {
    name: "Reshad Khan",
    code: "EMP-1180",
    site: "Port Louis yard",
    since: "08:14",
    status: "live"
  }, {
    name: "Yannick Labonne",
    code: "EMP-0307",
    site: "Curepipe depot",
    since: "07:30",
    status: "live"
  }, {
    name: "Devina Soobramanien",
    code: "EMP-0512",
    site: "Phoenix plant",
    since: "07:02",
    status: "live"
  }],
  rows: [{
    name: "Anjali Ramdin",
    code: "EMP-0421",
    site: "Port Louis yard",
    in: "07:58",
    out: "—",
    hours: "—",
    ot: "—",
    status: "live"
  }, {
    name: "Priya Nuckchady",
    code: "EMP-0096",
    site: "Phoenix plant",
    in: "06:55",
    out: "—",
    hours: "—",
    ot: "—",
    status: "live"
  }, {
    name: "Reshad Khan",
    code: "EMP-1180",
    site: "Port Louis yard",
    in: "08:14",
    out: "—",
    hours: "—",
    ot: "—",
    status: "late"
  }, {
    name: "Yannick Labonne",
    code: "EMP-0307",
    site: "Curepipe depot",
    in: "07:30",
    out: "16:30",
    hours: "8.0",
    ot: "0.0",
    status: "present"
  }, {
    name: "Devina Soobramanien",
    code: "EMP-0512",
    site: "Phoenix plant",
    in: "06:55",
    out: "17:25",
    hours: "9.5",
    ot: "1.0",
    status: "overtime"
  }, {
    name: "Sanjay Beeharry",
    code: "EMP-0233",
    site: "Port Louis yard",
    in: "—",
    out: "—",
    hours: "—",
    ot: "—",
    status: "leave"
  }, {
    name: "Marie-Lou Adam",
    code: "EMP-0888",
    site: "Curepipe depot",
    in: "—",
    out: "—",
    hours: "—",
    ot: "—",
    status: "absent"
  }, {
    name: "Kavi Ramphul",
    code: "EMP-0150",
    site: "Phoenix plant",
    in: "07:10",
    out: "13:00",
    hours: "5.5",
    ot: "0.0",
    status: "present"
  }, {
    name: "Fabrice Céleste",
    code: "EMP-0741",
    site: "Port Louis yard",
    in: "07:45",
    out: "17:02",
    hours: "8.5",
    ot: "0.5",
    status: "present"
  }, {
    name: "Naveena Goorah",
    code: "EMP-0619",
    site: "Phoenix plant",
    in: "08:02",
    out: "17:00",
    hours: "8.0",
    ot: "0.0",
    status: "late"
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/admin/data.js", error: String((e && e.message) || e) }); }

// ui_kits/clock/ClockScreen.jsx
try { (() => {
/* Muster — Employee /clock portal screen (touch-first) */
(function () {
  const {
    Button,
    StatusPill,
    Avatar
  } = window.MusterDesignSystem_7b1541;
  function ClockScreen() {
    const Ico = (n, s) => /*#__PURE__*/React.createElement("i", {
      "data-lucide": n,
      style: {
        width: s || 18,
        height: s || 18
      }
    });
    const [now, setNow] = React.useState(new Date());
    const [clockedIn, setClockedIn] = React.useState(false);
    const [since, setSince] = React.useState(null);
    const [toast, setToast] = React.useState(null);
    React.useEffect(() => {
      const t = setInterval(() => setNow(new Date()), 1000);
      return () => clearInterval(t);
    }, []);
    React.useEffect(() => {
      window.lucide && lucide.createIcons();
    });
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const ss = String(now.getSeconds()).padStart(2, "0");
    const dateStr = now.toLocaleDateString("en-GB", {
      weekday: "long",
      day: "numeric",
      month: "long"
    });
    const toggle = () => {
      if (!clockedIn) {
        const s = hh + ":" + mm;
        setSince(s);
        setClockedIn(true);
        setToast("You're clocked in. Punch recorded at " + s + ".");
      } else {
        setClockedIn(false);
        setToast("Clocked out. Have a good evening.");
      }
      setTimeout(() => setToast(null), 3200);
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--surface-page)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "16px 20px",
        background: "var(--brand-primary)",
        color: "#fff"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 30,
        height: 30,
        borderRadius: 8,
        background: "rgba(255,255,255,.16)",
        display: "grid",
        placeItems: "center"
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/favicon.svg",
      width: "20",
      height: "20",
      alt: "",
      style: {
        borderRadius: 4
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 17
      }
    }, "Muster"), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        fontSize: 12,
        background: "rgba(255,255,255,.16)",
        padding: "5px 10px",
        borderRadius: 999
      }
    }, Ico("map-pin", 13), " Port Louis yard")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px 22px",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: "Anjali Ramdin",
      size: 64,
      status: clockedIn ? "live" : "off"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 700,
        color: "var(--text-strong)",
        fontFamily: "var(--font-display)"
      }
    }, "Anjali Ramdin"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12.5,
        fontFamily: "var(--font-mono)",
        color: "var(--text-muted)"
      }
    }, "EMP-0421")), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 6
      }
    }, clockedIn ? /*#__PURE__*/React.createElement(StatusPill, {
      status: "live"
    }) : /*#__PURE__*/React.createElement(StatusPill, {
      status: "off",
      label: "Not clocked in"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 60,
        lineHeight: 1,
        color: "var(--text-strong)",
        letterSpacing: "-0.02em",
        marginTop: 12,
        fontVariantNumeric: "tabular-nums",
        display: "flex",
        alignItems: "baseline",
        gap: 2
      }
    }, hh, ":", mm, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 26,
        color: "var(--text-faint)"
      }
    }, ":", ss)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        color: "var(--text-muted)"
      }
    }, dateStr), clockedIn && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 4,
        fontSize: 13,
        color: "var(--text-muted)"
      }
    }, "On the clock since ", /*#__PURE__*/React.createElement("b", {
      style: {
        fontFamily: "var(--font-mono)",
        color: "var(--status-live-fg)"
      }
    }, since))), toast && /*#__PURE__*/React.createElement("div", {
      style: {
        margin: "0 18px",
        marginBottom: 8,
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "12px 14px",
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-md)",
        boxShadow: "var(--shadow-md)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--success)",
        display: "inline-flex"
      }
    }, Ico("check-circle-2", 18)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "var(--text-strong)"
      }
    }, toast)), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "12px 18px 22px",
        display: "flex",
        flexDirection: "column",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: clockedIn ? "primary" : "accent",
      size: "xl",
      fullWidth: true,
      onClick: toggle,
      iconLeft: Ico(clockedIn ? "log-out" : "fingerprint", 22),
      style: clockedIn ? {} : {
        boxShadow: "var(--shadow-accent)"
      }
    }, clockedIn ? "Clock out" : "Clock in"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 6,
        fontSize: 11.5,
        color: "var(--text-faint)"
      }
    }, Ico("shield-check", 13), " Inside geofence \xB7 QR verified")));
  }
  window.ClockScreen = ClockScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/clock/ClockScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/SiteScreen.jsx
try { (() => {
/* Muster — Supervisor /site portal (on-site roll call) */
(function () {
  const {
    StatusPill,
    Avatar,
    Input,
    Badge,
    IconButton
  } = window.MusterDesignSystem_7b1541;
  function SiteScreen() {
    const Ico = (n, s) => /*#__PURE__*/React.createElement("i", {
      "data-lucide": n,
      style: {
        width: s || 18,
        height: s || 18
      }
    });
    const D = window.MUSTER_DATA;
    const [tab, setTab] = React.useState("on");
    const [q, setQ] = React.useState("");
    React.useEffect(() => {
      window.lucide && lucide.createIcons();
    });
    const all = D.rows.filter(r => r.site === "Port Louis yard" || ["on", "expected"].includes(tab));
    const onSite = ["live", "present", "overtime", "late"];
    let list = D.rows;
    if (tab === "on") list = D.rows.filter(r => onSite.includes(r.status));
    if (tab === "absent") list = D.rows.filter(r => r.status === "absent" || r.status === "leave");
    list = list.filter(r => r.name.toLowerCase().includes(q.toLowerCase()));
    const TABS = [{
      id: "on",
      label: "On site",
      n: D.rows.filter(r => onSite.includes(r.status)).length
    }, {
      id: "expected",
      label: "Expected",
      n: D.rows.length
    }, {
      id: "absent",
      label: "Away",
      n: D.rows.filter(r => r.status === "absent" || r.status === "leave").length
    }];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "var(--surface-page)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "16px 18px 14px",
        background: "var(--surface-card)",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/favicon.svg",
      width: "26",
      height: "26",
      alt: ""
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 17,
        color: "var(--text-strong)"
      }
    }, "Port Louis yard"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: "var(--text-muted)"
      }
    }, "Supervisor \xB7 Fabrice C.")), /*#__PURE__*/React.createElement(Badge, {
      tone: "brand",
      variant: "soft"
    }, "Live")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 18,
        marginTop: 14
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 26,
        color: "var(--text-strong)",
        fontVariantNumeric: "tabular-nums"
      }
    }, "142"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10.5,
        letterSpacing: ".06em",
        textTransform: "uppercase",
        color: "var(--text-faint)"
      }
    }, "On site")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 26,
        color: "var(--text-strong)",
        fontVariantNumeric: "tabular-nums"
      }
    }, "178"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10.5,
        letterSpacing: ".06em",
        textTransform: "uppercase",
        color: "var(--text-faint)"
      }
    }, "Expected")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 26,
        color: "var(--status-absent-fg)",
        fontVariantNumeric: "tabular-nums"
      }
    }, "6"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10.5,
        letterSpacing: ".06em",
        textTransform: "uppercase",
        color: "var(--text-faint)"
      }
    }, "Away")))), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        height: 116,
        margin: 14,
        borderRadius: "var(--radius-md)",
        overflow: "hidden",
        border: "1px solid var(--border-subtle)",
        background: "linear-gradient(135deg, #E8EDE9 0%, #DDE6E0 100%)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        backgroundImage: "linear-gradient(var(--border-subtle) 1px, transparent 1px), linear-gradient(90deg, var(--border-subtle) 1px, transparent 1px)",
        backgroundSize: "26px 26px",
        opacity: .5
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: "50%",
        top: "50%",
        transform: "translate(-50%,-50%)",
        width: 92,
        height: 92,
        borderRadius: "50%",
        background: "color-mix(in oklch, var(--brand-primary) 16%, transparent)",
        border: "2px solid var(--brand-primary)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: "calc(50% - 4px)",
        top: "calc(50% - 22px)",
        color: "var(--brand-primary)"
      }
    }, Ico("map-pin", 22)), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: "calc(50% + 18px)",
        top: "calc(50% + 4px)",
        color: "var(--amber-600)"
      }
    }, Ico("map-pin", 18)), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        bottom: 8,
        left: 10,
        fontSize: 11,
        color: "var(--text-muted)",
        background: "rgba(255,255,255,.8)",
        padding: "2px 8px",
        borderRadius: 999
      }
    }, "Site geofence \xB7 150 m")), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "0 14px 10px",
        display: "flex",
        flexDirection: "column",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        background: "var(--surface-sunken)",
        borderRadius: "var(--radius-md)",
        padding: 3
      }
    }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => setTab(t.id),
      style: {
        flex: 1,
        border: "none",
        cursor: "pointer",
        padding: "8px 6px",
        borderRadius: "var(--radius-sm)",
        background: tab === t.id ? "var(--surface-card)" : "transparent",
        boxShadow: tab === t.id ? "var(--shadow-xs)" : "none",
        fontFamily: "var(--font-sans)",
        fontSize: 12.5,
        fontWeight: 600,
        color: tab === t.id ? "var(--text-strong)" : "var(--text-muted)"
      }
    }, t.label, " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-faint)"
      }
    }, t.n)))), /*#__PURE__*/React.createElement(Input, {
      placeholder: "Search roster\u2026",
      icon: Ico("search", 16),
      value: q,
      onChange: e => setQ(e.target.value),
      size: "sm"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        overflowY: "auto",
        padding: "0 8px 14px"
      }
    }, list.map(r => /*#__PURE__*/React.createElement("div", {
      key: r.code,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 11,
        padding: "10px 10px",
        borderRadius: "var(--radius-md)"
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: r.name,
      size: 38,
      status: r.status === "live" ? "live" : undefined
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13.5,
        fontWeight: 500,
        color: "var(--text-strong)"
      }
    }, r.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: "var(--text-muted)"
      }
    }, r.in !== "—" ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)"
      }
    }, "in ", r.in) : "—")), /*#__PURE__*/React.createElement(StatusPill, {
      status: r.status,
      size: "sm"
    })))));
  }
  window.SiteScreen = SiteScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/SiteScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.SidebarNav = __ds_scope.SidebarNav;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
