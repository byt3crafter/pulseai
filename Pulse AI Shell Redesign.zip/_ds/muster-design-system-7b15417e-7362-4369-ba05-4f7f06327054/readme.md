# Muster — Design System

**Muster** is a white-label, multi-tenant **workforce attendance, hours, leave & payroll-prep
SaaS**, built Mauritius-first and sellable to construction, manufacturing, retail and services
companies across the region. A *muster roll* is an attendance record — the name is the product.

Every customer ("tenant") gets the same engine wearing their own brand: their name, logo,
colours and copy. This design system is therefore built around a **theming seam** — two brand
variables (`--brand-primary`, `--brand-accent`) re-skin the entire product: admin shell, login,
the employee `/clock` portal, the supervisor `/site` portal, badges, buttons, generated PDFs
and QR posters.

> **Provenance / honesty note.** This system was designed *fresh*. The reference codebase
> (`/home/d0v1k/Projects/rrcl-attendance`) and any Figma files were **not accessible** in this
> session, so no real fonts, logos or colour values were extracted from source. The brand below
> — name "Muster", the teal+amber palette, the Space Grotesk / Hanken Grotesk / JetBrains Mono
> pairing, and the logo mark — is a **proposed** direction. Treat it as a strong v1 to react to,
> not a recovered ground truth. See **Caveats & how to iterate** at the bottom.

---

## What this product is (context)

A web app (Next.js App Router conventions assumed) with four surfaces:

1. **Admin shell** — HR / office / managers. Dashboard, daily attendance grid, employee
   profiles + photos, schedules, leave & overtime approvals, reports, payroll summary, settings,
   and a **Branding** page that drives the theme.
2. **`/clock`** — the employee self-service portal. Touch-first, used on phones at sites and
   gates; QR + geofence clock-in/out. Must be legible in bright outdoor light.
3. **`/site`** — the supervisor PWA. A foreman's roll-call view of who's on site, with a map.
4. **Generated artefacts** — branded payroll/report PDFs and printable QR posters.

The domain vocabulary that shapes the visuals: **present / clocked-in (live) / late / overtime /
absent / leave / holiday / day-off**, worked hours, Saturday half-day, OT minimum, geofence,
site, device (Hikvision webhook), schedule, pay rules.

### Sources given (store for whoever has access)
- **Reference codebase:** `/home/d0v1k/Projects/rrcl-attendance` — *not accessible this session.*
- Build brief: "Multi-Tenant White-Label Workforce Attendance SaaS" (Runstate Ltd).
- No Figma, no live URLs, no brand assets were provided.

---

## CONTENT FUNDAMENTALS — how Muster writes

**Voice: calm, precise, operational.** Muster talks like a good shift supervisor — clear,
unfussy, never hyped. It is software people use at 6am at a site gate; it respects their time.

- **Person.** Address the user as **you** ("You're clocked in", "Tap to clock out"). The system
  refers to itself rarely and never as "we" in-product. Marketing copy may use "we" for Runstate.
- **Casing.** Sentence case **everywhere** — buttons, headings, menus, table headers.
  ("Daily attendance", not "Daily Attendance".) Uppercase is reserved for **eyebrows/overlines
  and small labels** with wide tracking ("PAYROLL PERIOD", "ON SITE NOW").
- **Tense & length.** Present tense, short. Buttons are verbs: *Clock in, Approve, Export CSV,
  Save changes*. Empty states state the fact then the next action: *"No punches yet today.
  Employees appear here as they clock in."*
- **Numbers are first-class.** Times, hours and codes are always shown in the mono face with
  tabular figures: `07:58`, `8.5 h`, `EMP-0421`. Hours use `h` (lowercase), times use 24-hour
  `HH:MM`. Currency defaults to **MUR (Rs)**, timezone **UTC+4**.
- **Status language is fixed** (these are the StatusPill labels): *Present · On the clock · Late ·
  Overtime · Absent · On leave · Public holiday · Day off.* Don't invent synonyms.
- **Tone in errors.** Plain and blame-free. *"Couldn't save — check your connection and try
  again."* Never expose stack traces or codes to employees.
- **No emoji** in product UI. No exclamation marks except a genuine success moment on the
  employee portal ("You're clocked in."). Avoid jargon ("ingestion", "webhook") on employee-
  facing surfaces; it's fine in admin/settings.
- **Localisation.** English is primary; the product is bilingual-friendly (French / Mauritian
  Creole common among frontline staff). Keep strings short and translatable; avoid idiom.

**Examples**
- CTA: `Clock in` · `Clock out` · `Approve overtime` · `Add employee` · `Export payroll (CSV)`
- Toast: `Saved. Branding updated.` · `Punch recorded at 07:58.`
- Eyebrow: `ON SITE NOW` · `PAY PERIOD · 1–15 JUN`
- Empty: `No sites yet. Add a site to start tracking attendance.`

---

## VISUAL FOUNDATIONS

**Overall vibe:** a *precise instrument*. Think a well-made time clock and a clean ledger — warm
but exacting. Data-dense where it counts (admin tables), generous and high-contrast where hands
are involved (the `/clock` portal). Deliberately **not** the generic SaaS look: no purple
gradients, no glassmorphism, no emoji cards, no rounded-corner-with-colored-left-border cards.

### Colour
- **Primary — Teal-green** (`--teal-600 #0C8169`). A heritage nod (the original app's green) and
  to Mauritius greenery; reads trustworthy and operational. Drives nav, primary buttons, links,
  focus rings, key data accents.
- **Accent — Amber** (`--amber-400 #F5A623`). The "**on the clock / live**" colour — sunlit,
  energetic, used sparingly for the active state, the live clock CTA, and highlights. Never the
  dominant colour.
- **Neutrals — warm green-tinted stone.** Surfaces are `--stone-50` page / white cards, ink is
  `--stone-900`. The slight warmth keeps it human, not clinical blue-gray.
- **Feedback:** success green, warning amber, danger red, info blue — each with a soft tint bg.
- **Attendance status palette** is the signature: present (teal), on-the-clock (amber, pulsing),
  late (deep amber), overtime (orange), absent (red), leave (violet), holiday (blue), off (gray).
  Always **soft-tint background + saturated dot + dark-tint text** — never full-saturation fills.
- Use brand tokens, never raw hex, in UI. The **two brand vars are the white-label knob** — a
  tenant overrides `--brand-primary`/`--brand-accent` and everything follows.

### Typography
- **Display — Space Grotesk** (technical geometric grotesk): page titles, metrics, the live
  clock readout. Tight tracking (`-0.02em`).
- **UI / body — Hanken Grotesk** (warm humanist): everything else; excellent at 13–14px.
- **Mono — JetBrains Mono** with **tabular figures**: every time, hour, employee code and
  table number column, so digits line up.
- Base UI size **14px**. Never below **12px**. Big metrics 34px, live clock 52px.

### Spacing & layout
- **4px grid.** Page gutter 24px, card padding 20px. Sidebar 248px (collapses to 64px), topbar
  60px, content max 1280px.
- Touch surfaces (`/clock`, `/site`) honour a **44px minimum hit target**; the primary clock-in
  button is 60px tall.
- Tables are dense (row height ~44px) with sticky, sunken (`--surface-sunken`) headers and
  right-aligned mono number columns.

### Surfaces, borders, radius, shadow
- **Cards:** white surface, **1px hairline border** (`--border-subtle`) **+ a barely-there
  shadow** (`--shadow-sm`). Radius **10px** (`--radius-md`). Not bubbly, not borderless.
- Radii: 4/6/10/14/20px + pill. Inputs & buttons 10px; panels/dialogs 14px; portal hero 20px;
  pills, avatars, toggles fully round.
- **Shadows are cool-neutral, low and tight** — elevation by layering, not by heavy drops. Two
  brand-tinted glows exist *only* for the live clock-in CTA (`--shadow-brand`/`--shadow-accent`).
- Borders are the primary separation device; shadows are secondary. Sunken wells use an inset
  shadow.

### Motion
- **Calm and mechanical.** 140ms hovers/presses, 220ms most transitions, 360ms panels. Easing is
  crisp (`--ease-snap` / `--ease-out`) — **no bounce, no long flourishes.**
- **Hover:** subtle — surfaces lift to `--surface-card` / borders darken one step / buttons
  darken ~6%. **Press:** scale to 0.98 + slightly stronger inset; no colour party.
- **One signature animation:** the `muster-live-pulse` ring on the "on the clock" status dot —
  a slow expanding amber halo. Reserve animation for live/real-time states; static data never
  animates. All motion respects `prefers-reduced-motion`.

### Imagery & texture
- Photography is **employee portraits** (enrolled headshots, neutral) and **site/worksite**
  photos — natural daylight, warm, documentary, not stocky. Map tiles are OpenStreetMap with a
  muted treatment and teal geofence circles / pins.
- No decorative gradients in product. A single optional brand texture exists: a faint
  tally / roster dot pattern (see `assets/`), used at very low opacity on login and poster
  headers only.
- Transparency/blur: used only for overlays/scrims behind dialogs and the impersonation banner
  — a `--surface-inverse` scrim at ~45%, light backdrop blur. Not a decorative motif.

---

## ICONOGRAPHY

- **Icon set: [Lucide](https://lucide.dev)** — loaded from CDN (`lucide@latest`). Chosen for its
  clean, consistent **1.75px stroke**, geometric-but-friendly forms that sit naturally next to
  Hanken/Space Grotesk, and broad coverage of the domain (clock, map-pin, fingerprint, users,
  calendar-check, file-text, qr-code). This is a **substitution** — the original codebase's icon
  choice was not accessible. Flag for review.
- **Usage rules:** default 18–20px in UI, 16px inline with text, 24px+ on touch surfaces. Stroke
  inherits `currentColor`; never recolour an icon outside the status palette. Pair an icon with a
  text label for any primary action — icon-only buttons get an accessible label + tooltip.
- **No emoji** anywhere in product. No Unicode-glyph icons. The only non-Lucide marks are the
  Muster logo (`assets/`) and the status **dots** (drawn as CSS circles, not icons).
- In UI-kit/specimen HTML, Lucide is loaded via `<script src="https://unpkg.com/lucide@latest">`
  then `lucide.createIcons()` — and rendered with `<i data-lucide="clock"></i>`.

---

## INDEX — what's in this folder

**Foundations**
- `styles.css` — the single entry point consumers link (only `@import`s).
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `elevation.css`,
  `motion.css`, `base.css`.
- `guidelines/*.html` — foundation specimen cards (Type, Colors, Spacing, Brand).

**Assets** — `assets/`
- `muster-mark.svg`, `muster-wordmark.svg`, `favicon.svg` (logo lockups), brand pattern.

**Components** — `components/<group>/` (each: `Name.jsx` + `Name.d.ts` + `Name.prompt.md` + a
`*.card.html`). Groups: `core/` (Button, IconButton), `forms/` (Input, Select, Checkbox, Switch),
`data/` (Card, StatCard, Avatar), `feedback/` (StatusPill, Badge, Toast), `navigation/` (Tabs,
SidebarNav). Mount via `window.Muster.<Name>`.

**UI kits** — `ui_kits/<product>/` (`index.html` + screen JSX)
- `admin/` — dashboard + daily attendance grid.
- `clock/` — employee clock-in portal (touch).
- `site/` — supervisor on-site roll-call PWA.

**Skill** — `SKILL.md` (makes this folder usable as a downloadable Claude skill).

---

## Caveats & how to iterate

**Caveats (please read):**
1. **Nothing was extracted from the real codebase** — it wasn't reachable. Brand name, colours,
   fonts and logo are proposals.
2. **Fonts are Google-hosted substitutions** (Space Grotesk / Hanken Grotesk / JetBrains Mono).
   If you have brand fonts, send the `.woff2` files and I'll self-host them.
3. The **logo mark is hand-built** for this proposal; if there's an existing Muster/tenant logo,
   share it and I'll replace every lockup.

**The bold ask:** tell me which of these to lock or change —
- the **name** (Muster vs Pointe vs Lerla vs your own),
- the **primary + accent colours** (teal/amber, or your brand pair),
- the **type pairing**,
and **attach the codebase/Figma/logo** if you have them. With any one of those I can make this
pixel-accurate instead of a strong guess.
